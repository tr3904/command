import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-masthead',
  templateUrl: './masthead.component.html',
  styleUrls: []
})
export class MastheadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
