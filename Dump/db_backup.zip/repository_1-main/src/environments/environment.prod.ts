export const environment = {
  production: true,
  api: {
    base: 'http://localhost:5000/api',
    entries: 'blogs'
  }
};
