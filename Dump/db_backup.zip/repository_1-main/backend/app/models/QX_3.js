import React from 'react';
import Template1 from './components/Template1';
import Template2 from './components/Template2';

function App() {
    return (
      <div className="App">
        <Template1 />
        <Template2 />

      </div>
    );
}

export default App;